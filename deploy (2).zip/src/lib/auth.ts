// ═══════════════════════════════════════════════════════════════════════════
// FormBridge AI - File-Based Persistent User Store
// ═══════════════════════════════════════════════════════════════════════════

import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import type { User } from '@/types/auth';

const JWT_SECRET = process.env.JWT_SECRET || 'formbridge-ai-secret-key-change-in-production';
const INITIAL_CREDITS = 10;

// File path for persistent storage
const DATA_DIR = path.join(process.cwd(), '.data');
const USERS_FILE = path.join(DATA_DIR, 'users.json');

interface StoredUser extends User {
    passwordHash: string;
    // @ts-ignore - Ensure deviceId is optional in StoredUser if it's optional in User, but here it's fine.
    deviceId?: string;
    verificationToken?: string;
    isVerified?: boolean;
}

interface UsersData {
    users: Record<string, StoredUser>;
}

// Ensure data directory exists
function ensureDataDir(): void {
    if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
    }
}

// Load users from file
function loadUsers(): Record<string, StoredUser> {
    try {
        ensureDataDir();
        if (fs.existsSync(USERS_FILE)) {
            const data = fs.readFileSync(USERS_FILE, 'utf-8');
            const parsed: UsersData = JSON.parse(data);
            return parsed.users || {};
        }
    } catch (error) {
        console.error('Error loading users:', error);
    }
    return {};
}

// Save users to file
function saveUsers(users: Record<string, StoredUser>): void {
    try {
        ensureDataDir();
        const data: UsersData = { users };
        fs.writeFileSync(USERS_FILE, JSON.stringify(data, null, 2), 'utf-8');
    } catch (error) {
        console.error('Error saving users:', error);
    }
}

export async function createUser(name: string, email: string, password: string, deviceId?: string): Promise<User | null> {
    const users = loadUsers();

    if (users[email]) {
        return null; // User already exists
    }

    // Check for duplicate deviceId if provided
    if (deviceId) {
        const existingDeviceUser = Object.values(users).find(user => user.deviceId === deviceId);
        if (existingDeviceUser) {
            console.warn(`Blocked registration attempt from duplicate device: ${deviceId}`);
            throw new Error('This device is already registered. Only one account per device is allowed.');
        }
    }

    const verificationToken = crypto.randomUUID();

    const passwordHash = await bcrypt.hash(password, 10);
    const user: StoredUser = {
        id: `user_${Date.now()}`,
        email,
        name,
        credits: INITIAL_CREDITS,
        createdAt: new Date().toISOString(),
        passwordHash,
        deviceId,
        isVerified: false,
        verificationToken,
    };

    users[email] = user;
    saveUsers(users);

    const { passwordHash: _, ...safeUser } = user;
    return safeUser;
}

export async function validateUser(email: string, password: string): Promise<User | null> {
    const users = loadUsers();
    const user = users[email];
    if (!user) return null;

    const isValid = await bcrypt.compare(password, user.passwordHash);
    if (!isValid) return null;

    if (user.isVerified === false) {
        console.warn(`Login attempt for unverified user: ${email}`);
        return null;
    }

    const { passwordHash: _, ...safeUser } = user;
    return safeUser;
}

export function getUserByEmail(email: string): User | null {
    const users = loadUsers();
    const user = users[email];
    if (!user) return null;

    const { passwordHash: _, ...safeUser } = user;
    return safeUser;
}

export function updateUserCredits(email: string, credits: number): boolean {
    const users = loadUsers();
    const user = users[email];
    if (!user) return false;

    user.credits = credits;
    users[email] = user;
    saveUsers(users);
    return true;
}

export function deductUserCredits(email: string, amount: number): { success: boolean; newCredits: number } {
    const users = loadUsers();
    const user = users[email];
    if (!user) return { success: false, newCredits: 0 };

    if (user.credits < amount) {
        return { success: false, newCredits: user.credits };
    }

    user.credits -= amount;
    users[email] = user;
    saveUsers(users);
    return { success: true, newCredits: user.credits };
}

export function addUserCredits(email: string, amount: number): { success: boolean; newCredits: number } {
    const users = loadUsers();
    const user = users[email];
    if (!user) return { success: false, newCredits: 0 };

    user.credits += amount;
    users[email] = user;
    saveUsers(users);
    return { success: true, newCredits: user.credits };
}

export function generateToken(user: User): string {
    return jwt.sign({ id: user.id, email: user.email }, JWT_SECRET, { expiresIn: '7d' });
}

export function verifyToken(token: string): { id: string; email: string } | null {
    try {
        return jwt.verify(token, JWT_SECRET) as { id: string; email: string };
    } catch {
        return null;
    }
}

export async function verifyUserAccount(token: string): Promise<User | null> {
    const users = loadUsers();
    // Search for user with this token
    const userEmail = Object.keys(users).find(email => users[email].verificationToken === token);

    if (!userEmail) return null;

    const user = users[userEmail];
    user.isVerified = true;
    user.verificationToken = undefined; // Clear token

    users[userEmail] = user;
    saveUsers(users);

    const { passwordHash: _, ...safeUser } = user;
    return safeUser;
}
